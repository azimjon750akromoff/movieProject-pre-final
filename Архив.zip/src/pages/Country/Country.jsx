import React from "react";

function Country() {
  return <div className="country">
      <h1>hello</h1>

  </div>;
}

export default Country;
