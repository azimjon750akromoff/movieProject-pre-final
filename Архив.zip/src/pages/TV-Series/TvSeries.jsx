import React from 'react'

function TvSeries() {
  return (
    <div className='tvseries'>
      <h1>hello</h1>
    </div>
  )
}

export default TvSeries
